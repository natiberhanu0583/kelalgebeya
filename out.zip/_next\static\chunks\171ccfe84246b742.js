__turbopack_load_page_chunks__("/_error", [
  "static/chunks/fb857e0b3814bbac.js",
  "static/chunks/e65d78c141327e00.js",
  "static/chunks/turbopack-15ef0022e91aea8e.js"
])
