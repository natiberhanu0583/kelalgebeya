__turbopack_load_page_chunks__("/_app", [
  "static/chunks/5a366172d6aa21d8.js",
  "static/chunks/bf7fd36cc36d5c51.js",
  "static/chunks/turbopack-c701b6a1de67249e.js"
])
