__turbopack_load_page_chunks__("/_app", [
  "static/chunks/5a366172d6aa21d8.js",
  "static/chunks/0ab086100deb8f6c.js",
  "static/chunks/turbopack-4ab8834c2843084c.js"
])
