__turbopack_load_page_chunks__("/_error", [
  "static/chunks/fb857e0b3814bbac.js",
  "static/chunks/ad8221802ec61b46.js",
  "static/chunks/turbopack-1dac015ee763a686.js"
])
