__turbopack_load_page_chunks__("/_error", [
  "static/chunks/fb857e0b3814bbac.js",
  "static/chunks/bf7fd36cc36d5c51.js",
  "static/chunks/turbopack-2fae4e240a49a262.js"
])
