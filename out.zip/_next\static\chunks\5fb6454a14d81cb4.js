__turbopack_load_page_chunks__("/_app", [
  "static/chunks/5a366172d6aa21d8.js",
  "static/chunks/ad8221802ec61b46.js",
  "static/chunks/turbopack-470adb4fcd04440c.js"
])
