__turbopack_load_page_chunks__("/_app", [
  "static/chunks/5a366172d6aa21d8.js",
  "static/chunks/e65d78c141327e00.js",
  "static/chunks/turbopack-7b32c6b96b9e281e.js"
])
